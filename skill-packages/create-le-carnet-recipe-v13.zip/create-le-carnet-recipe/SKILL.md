---
name: create-le-carnet-recipe
description: Skapa, bearbeta, paketera och validera svenska recept för Le Carnet du Nord med bilder. Använd automatiskt när användaren beskriver, klistrar in, diskuterar, ändrar eller godkänner ett recept i Le Carnet-sammanhang, även utan att uttryckligen be om skillen. Omvandla receptunderlaget till ett komplett granskningsutkast med makron, tider, fransk restaurangtitel, klassificering, allergener och bild; publicera aldrig utan separat uttryckligt godkännande.
---

# Skapa Le Carnet-recept

## Automatisk aktivering och standardsvar

- Behandla varje recept, råvarulista, maträttsidé eller fortsättning på en receptdiskussion i ett Le Carnet-projekt som en begäran att köra hela arbetsflödet.
- Användaren behöver inte skriva "använd skillen", "enligt mina vanliga instruktioner" eller räkna upp vilka receptfält som behövs.
- Börja omedelbart skapa eller uppdatera det kompletta granskningsutkastet. Kommentera, beröm, sammanfatta eller bekräfta inte bara receptet.
- Presentera receptets fullständiga redaktionella innehåll i chatten så att användaren kan granska och begära ändringar innan publicering.
- Om ingen användbar huvudbild har bifogats och bildgenerering finns tillgänglig, skapa automatiskt en fotorealistisk `hero.webp`-bild av den färdiga rätten i Le Carnets nordiskt-franska bildstil.
- Håll alltid receptet i `review` eller `draft` tills användaren separat och uttryckligen godkänner publicering.

## Arbetsflöde

Vid hämtning eller validering av ett befintligt paket via GitHub, läs hämtningsavsnittet i `references/github-publicering.md`: bilder hämtas med uttrycklig base64-kodning och avkodas till ursprungliga bytes.

1. Läs `references/recipe-schema.md` innan du skapar eller ändrar recept.
   Om användaren vill uppdatera ett befintligt recept ska du även läsa och följa `references/uppdatera-befintligt-recept.md` innan något utkast skapas.
2. Samla receptets råvaror, råvikter, portioner, tider och separata bilder. Fråga endast efter uppgifter som blockerar en rimlig beräkning eller säker instruktion.
3. Välj dominant `protein_group` och `carb_group` på grov råvarunivå. Använd inte kryddor eller små tillbehör.
4. Skriv en tydlig svensk titel och en återhållsamt elegant, idiomatisk fransk `restaurant_title`. Bevara rättens identitet.
5. Beräkna näring från generiska råvaruvärden och råvikter. Summera hela receptet, dividera med portioner och rimlighetskontrollera energin. Hitta inte på precision; sätt `draft` om underlaget inte räcker.
6. Skapa `<slug>/recipe.md`. Kopiera/optimera en bifogad huvudbild som `hero.webp`, eller generera automatiskt huvudbilden när ingen bild har bifogats och bildgenerering finns tillgänglig. Använd `illustrations.json` och `step-NN-kind-XX.webp` för valfria stegbilder enligt illustrationsstandarden. Ändra aldrig källbilder destruktivt.
7. Säkerställ att de fem automatiska faktarikonerna kan visas: total tid, aktiv tid, portioner, kcal per portion och måltidstyp. De skapas av sajten från receptets metadata och ska inte levereras som separata bildfiler.
8. Planera och generera stegillustrationer för relevanta moment och resultat. Visa Hero och samtliga föreslagna stegillustrationer i chatten med stegnummer, bildtyp och caption. Låt användaren fritt lägga till, ta bort och göra om; visa en ny komplett översikt tills hela uppsättningen är godkänd. Ingen gräns på antal bilder.
9. Läs `references/recipe-files.md` för tillåtna paketfiler och `references/timers.md`, granska varje stegtid och skapa `timers.json`. Filen krävs även när listan är tom. Täck alla uttryckliga tider och separata faser; hitta inte på tider för vaga formuleringar. Kör `node scripts/validate-recipe.mjs <receptmapp>`. Åtgärda alla fel. Varningar kräver redaktionellt ställningstagande.
10. Sätt `published` först efter uttryckligt godkännande av recepttext, Hero och samtliga bilder. Paketera endast receptmappen, utan temporära filer.
11. När användaren uttryckligen ber att publicera till Le Carnet, läs `references/github-publicering.md`. I ChatGPT Work ska den aktiva GitHub-pluginen användas direkt; kräv inte lokal klon. Publicera till det privata recept-repot först efter lyckad validering. Ett vanligt önskemål om att skapa eller granska ett recept innebär inte tillstånd att skicka något externt.

## Regler

- Följ den lokala projektspecifikationen om den är nyare än den bundlade referensen.
- Använd svenska mått, °C och ISO-datum.
- Ange allergener efter aktiv kontroll.
- Bevara `id` efter första publicering och uppdatera `updated_at` vid innehållsändring.
- När ett befintligt recept uppdateras måste originalet först hämtas från receptarkivet. Skapa aldrig ett nytt recept eller nytt ID som reserv om originalet inte kan hittas.
- Generera aldrig egna ikonbilder för faktafält. Använd alltid sajtens gemensamma, lokala ikonsystem så att uttryck, tillgänglighet och filstorlek förblir konsekventa.
- Ändra styrande dokument och validator tillsammans när schemaformatet ändras.
- Efter lyckad validering är hela paketet låst. Publicera exakt de validerade filbytesen och ändra eller räkna aldrig om innehåll, mängder, bilder eller näringsvärden i publiceringssteget.
- Varje steg under `Gör så här` ska ligga på exakt en egen rad och ha exakt en yttre numrering. Lämna aldrig kvar en extra `2.`, `5.` eller annan listmarkör i stegets rubrik eller brödtext.


## Normerande illustrationsstandard

Läs `references/illustrations.md` och `references/recipe-schema.md`. När projektets `docs/ILLUSTRATIONS.md` finns är den normerande för projektet. Svartvit tunn tuschteckning i fransk kokboks-/modern instruktionsstil; **endast råvaror och mat** har diskreta dova färger. **Ingen text i bilden**; vid behov separat caption. `action`, `result`, `detail`; 0..N illustrationer per steg. Bildpaketet får inte publiceras innan det har visats i sin helhet och användaren separat har godkänt slutversionen. Ändringar efter granskning kräver en ny granskning. Inga nya bilder får skapas efter publiceringsgodkännande.

## Visuella steg-timers

Receptstandard v10 kräver timers.json i varje nytt eller uppdaterat receptpaket. Använd en tom timers-lista när stegen saknar uttryckliga tider. App 1.6.0 visar timrarna; äldre recept utan fil kan fortfarande läsas. Märk endast upp uttryckliga tillagningstider manuellt. Använd stabila ID:n, 1-baserat steg, label och seconds (10–86400). Intervall får nedre gränsen som kontrolltimer och hela intervallet i note. Flera faser får separata tydligt namngivna timers. Skala aldrig tid med portioner. Ingen ljudfunktion ingår. Se references/timers.md och kör validatorn. Vid ändrad stegföljd ska timrarnas stegkoppling granskas.

## Gemensamma mängder – arbetsflöde

För nya recept eller när portionsskalning införs, läs `references/portion-scaling.md`. Använd quantities.json och samma referenser i ingredienslista och steg. Behåll antal bakverk, bitar och serveringskärl enligt grundreceptet; sajten visar en notis vid skalning. Granska 1, grundantal och dubbelt antal portioner. Ändra inte befintliga bilder eller makron vid en ren formatkonvertering.
