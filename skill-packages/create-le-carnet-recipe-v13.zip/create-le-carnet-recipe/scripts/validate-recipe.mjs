#!/usr/bin/env node
import { validateTimers } from './step-timers.mjs';
import { validateRecipeFiles } from './recipe-files.mjs';
import { validateTimerCoverage } from './timer-coverage.mjs';
import fs from 'node:fs';
import path from 'node:path';
import { validateIllustrations } from './validate-illustrations.mjs';
import { validateQuantityReferences } from './quantity-references.mjs';

const dir = path.resolve(process.argv[2] || '.');
const packageErrors = validateRecipeFiles(dir);
if (packageErrors.length) {
  for (const error of packageErrors) console.error(`FEL: ${error}`);
  process.exit(1);
}
const file = path.join(dir, 'recipe.md');
const errors = [];
const warnings = [];
const fail = (m) => errors.push(m);

if (!fs.existsSync(file)) fail('recipe.md saknas');
let text = fs.existsSync(file) ? fs.readFileSync(file, 'utf8') : '';
const match = text.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n/);
if (!match) fail('Giltig YAML-frontmatter saknas');
const yaml = match?.[1] || '';

function scalar(key) {
  const m = yaml.match(new RegExp(`^${key}:\\s*(.+?)\\s*$`, 'm'));
  return m ? m[1].replace(/^['"]|['"]$/g, '') : null;
}
function nested(section, key) {
  const m = yaml.match(new RegExp(`^${section}:\\s*\\r?\\n(?:^[ \\t]+.*\\r?\\n)*?^[ \\t]+${key}:\\s*(.+?)\\s*$`, 'm'));
  return m ? m[1].replace(/^['"]|['"]$/g, '') : null;
}

const required = ['schema_version','id','slug','title','restaurant_title','summary','status','published_at','updated_at','servings','prep_minutes','cook_minutes','total_minutes','protein_group','carb_group','meal_type','tags','allergens','hero_image','hero_alt'];
for (const key of required) if (!scalar(key)) fail(`Fält saknas: ${key}`);
for (const key of ['basis','kcal','protein_g','carbs_g','fat_g','fiber_g','method']) if (!nested('nutrition', key)) fail(`Näringsfält saknas: nutrition.${key}`);

const slug = scalar('slug');
if (slug && !/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug)) fail('slug måste vara kebab-case utan å/ä/ö');
if (slug && path.basename(dir) !== slug) fail('Katalognamnet måste matcha slug');
if (scalar('id') && scalar('id') !== slug) fail('id och slug måste matcha för nya recept');
if (scalar('schema_version') !== '1') fail('schema_version måste vara 1');
if (!['draft','review','published','archived'].includes(scalar('status'))) fail('Ogiltig status');
const allowedCarbs = ['pasta','ris','potatis','bröd','nudlar','gryn','baljväxter','lågkolhydrat','övrigt'];
if (scalar('carb_group') && !allowedCarbs.includes(scalar('carb_group').toLowerCase())) fail(`Ogiltig carb_group. Använd en grov grupp: ${allowedCarbs.join(', ')}`);

for (const key of ['servings','prep_minutes','cook_minutes','total_minutes']) {
  const value = Number(scalar(key));
  if (!Number.isInteger(value) || value <= 0) fail(`${key} måste vara ett positivt heltal`);
}
const prep = Number(scalar('prep_minutes')), cook = Number(scalar('cook_minutes')), total = Number(scalar('total_minutes'));
if (Number.isFinite(total) && total < prep + cook) fail('total_minutes får inte vara mindre än prep_minutes + cook_minutes');

for (const key of ['kcal','protein_g','carbs_g','fat_g','fiber_g']) {
  const value = Number(nested('nutrition', key));
  if (!Number.isFinite(value) || value < 0) fail(`nutrition.${key} måste vara ett icke-negativt tal`);
}
if (nested('nutrition','basis') !== 'per portion') fail('nutrition.basis måste vara "per portion"');
const kcal = Number(nested('nutrition','kcal'));
const macroKcal = 4 * Number(nested('nutrition','protein_g')) + 4 * Number(nested('nutrition','carbs_g')) + 9 * Number(nested('nutrition','fat_g'));
if (kcal > 0 && Math.abs(macroKcal - kcal) / kcal > 0.15) warnings.push('Makron avviker mer än 15 % från angivna kcal');

const headings = ['Ingredienser','Gör så här','Serveringstips','Varför det blir så gott','Förvaring'];
let prior = -1;
for (const heading of headings) {
  const hits = [...text.matchAll(new RegExp(`^## ${heading.replace(/[.*+?^${}()|[\\]\\]/g, '\\$&')}\\s*$`, 'gm'))];
  if (hits.length !== 1) fail(`Sektionen "${heading}" måste förekomma exakt en gång`);
  else if (hits[0].index < prior) fail('Sektionerna ligger i fel ordning');
  else prior = hits[0].index;
}
function sectionText(name) {
  const escaped = name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const header = new RegExp(`^## ${escaped}\\s*$`, 'm').exec(text);
  if (!header) return '';
  const rest = text.slice(header.index + header[0].length);
  const next = /^##\s+/m.exec(rest);
  return rest.slice(0, next ? next.index : rest.length).trim();
}
const ingredientText = sectionText('Ingredienser');
const ingredientGroups = [...ingredientText.matchAll(/^###\s+(.+)$/gm)];
if (!ingredientGroups.length) fail('Ingredienser måste delas in under minst en ###-underrubrik');
for (let i = 0; i < ingredientGroups.length; i += 1) {
  const start = ingredientGroups[i].index + ingredientGroups[i][0].length;
  const end = ingredientGroups[i + 1]?.index ?? ingredientText.length;
  if (!/^-\s+\S/m.test(ingredientText.slice(start, end))) fail(`Ingrediensgruppen "${ingredientGroups[i][1]}" saknar punktlistade ingredienser`);
}
for (const heading of ['Serveringstips', 'Varför det blir så gott']) {
  if (!/^-\s+\S/m.test(sectionText(heading))) fail(`Sektionen "${heading}" måste innehålla minst en punkt`);
}
let quantities;
const quantityPath = path.join(dir, 'quantities.json');
if (fs.existsSync(quantityPath)) {
  try {
    if (fs.statSync(quantityPath).size > 100_000) throw new Error('För stor quantities.json');
    quantities = JSON.parse(fs.readFileSync(quantityPath, 'utf8'));
  } catch (error) { fail(`Ogiltig quantities.json: ${error.message}`); }
}
for (const error of validateQuantityReferences(quantities, ingredientText, sectionText('Gör så här'))) fail(error);
const outsideQuantities = text.replace(ingredientText, '').replace(sectionText('Gör så här'), '');
if (outsideQuantities.includes('{{q:')) fail('Mängdreferenser tillåts bara i ingrediensrader och steg');

const instructionLines = sectionText('Gör så här').split(/\r?\n/).filter(line => line.trim());
if (!instructionLines.length) fail('Gör så här måste innehålla numrerade steg');
instructionLines.forEach((line, index) => {
  const step = line.match(/^(\d+)\.\s+(.+)$/);
  if (!step) return fail(`Instruktionsrad ${index + 1} måste vara exakt ett numrerat steg`);
  if (Number(step[1]) !== index + 1) fail(`Instruktionsstegen måste numreras obrutet från 1; hittade ${step[1]} på rad ${index + 1}`);
  if (/(?:^|\s)\d+\.\s+[A-ZÅÄÖ]/.test(step[2])) fail(`Steg ${step[1]} innehåller en extra numreringsrest`);
});

const image = scalar('hero_image');
if (image) {
  if (!/\.(webp|avif)$/i.test(image)) fail('hero_image måste vara WebP eller AVIF');
  const imagePath = path.resolve(dir, image);
  if (!imagePath.startsWith(dir + path.sep) || !fs.existsSync(imagePath)) fail('hero_image saknas eller pekar utanför receptmappen');
  else if (fs.statSync(imagePath).size > 500 * 1024) warnings.push('Hero-bilden är större än 500 KB');
}

for (const d of ['published_at','updated_at']) if (scalar(d) && !/^\d{4}-\d{2}-\d{2}$/.test(scalar(d))) fail(`${d} måste vara YYYY-MM-DD`);

validateIllustrations({dir, stepCount: instructionLines.length, fail, warnings});
const timerFile = path.join(dir, 'timers.json');
let timerManifest;
if (fs.existsSync(timerFile)) {
  try {
    if (fs.statSync(timerFile).size > 100_000) throw new Error('För stor timers.json');
    timerManifest = JSON.parse(fs.readFileSync(timerFile,'utf8'));
    const timerErrors = validateTimers(timerManifest, instructionLines.length);
    for (const error of timerErrors) fail(error);
    if (timerErrors.length) timerManifest = undefined;
  } catch (error) { fail(`Ogiltig timers.json: ${error.message}`); }
}
for (const error of validateTimerCoverage(instructionLines, timerManifest)) fail(error);

for (const warning of warnings) console.warn(`VARNING: ${warning}`);
for (const error of errors) console.error(`FEL: ${error}`);
if (errors.length) process.exit(1);
console.log(`OK: ${path.basename(dir)} är giltigt (${warnings.length} varningar)`);

