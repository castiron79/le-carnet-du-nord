# Receptschema 1

Den normativa projektspecifikationen finns i `docs/RECIPE-SPEC.md`. När skillen används utanför projektet gäller följande miniminivå:

- En katalog vars kebab-case-namn matchar `slug` och `id`.
- `recipe.md` med YAML-frontmatter.
- Obligatoriska fält: `schema_version`, `id`, `slug`, `title`, `restaurant_title`, `summary`, `status`, `published_at`, `updated_at`, `servings`, `prep_minutes`, `cook_minutes`, `total_minutes`, `protein_group`, `carb_group`, `meal_type`, `tags`, `allergens`, `hero_image`, `hero_alt` och hela `nutrition`.
- Sektioner: Ingredienser, Gör så här, Serveringstips, Varför det blir så gott, Förvaring.
- `Gör så här`: ett komplett steg per fysisk rad, obrutet numrerat från `1.`. Inga inbäddade eller överblivna numreringar får förekomma inne i ett steg.
- `Ingredienser` ska ha minst en `###`-underrubrik och varje ingrediensgrupp ska innehålla en Markdown-punktlista.
- `Serveringstips` och `Varför det blir så gott` ska vardera innehålla minst en Markdown-punkt. Vanliga löptextstycken är inte giltiga där.
- `nutrition` är per portion och innehåller kcal, protein, kolhydrater, fett, fiber och metod.
- Hero ska vara WebP/AVIF och finnas i samma katalog.

## Automatiska faktarikoner

Sajten renderar fem små linjeikoner automatiskt från befintlig metadata:

- klocka från `total_minutes`;
- kokkärl/värme från `cook_minutes`;
- portioner från `servings`;
- näring från `nutrition.kcal`;
- serveringskategori från `meal_type`.

Receptpaketet ska därför inte innehålla separata ikonfiler eller ikon-URL:er. Saknade metadatafält ska rättas före publicering.

Makron beräknas från generiska värden per 100 g och råvikter. Avrunda först efter summering och division med portioner. Kontrollera kcal mot 4/4/9-formeln med cirka 15 % tolerans. Otillräckligt underlag innebär `draft`, aldrig fabricerade värden.

Efter godkännande ska det kompletta receptpaketet valideras och därefter behandlas som oföränderligt. Publicera exakt de validerade filbytesen; räkna inte om näring, ändra inte mängder och formatera inte om text efter valideringen.

Vid uppdatering av ett publicerat recept är katalognamn, `id`, `slug`, `schema_version` och `published_at` identitetsfält och får inte ändras. Kandidaten ska vara en fullständig kopia av baspaketet, verifieras mot basen med `verify-recipe-update.mjs` och följa `uppdatera-befintligt-recept.md`.

## Stegillustrationer (bakåtkompatibelt tillägg v1.0)

Ett recept kan valfritt ha `illustrations.json` bredvid `recipe.md` och Hero. Formen är `{"version":1,"illustrations":[{"step":2,"kind":"result","file":"step-02-result-01.webp","alt":"...","caption":"..."}]}`. Stegindex är 1-baserat; kind=action/result/detail; flera bilder per steg och inget maxantal. Bilden saknar text, caption hålls utanför, bara råvaror/mat har subtila färger. Alla bilder ska visas för användaren och godkännas innan publicering; tomt eller uteblivet manifest fungerar för bildlösa recept. Full standard i projektets `docs/ILLUSTRATIONS.md`.

## Gemensamma mängder (app 1.5.0, skill v8)

Valfria quantities.json version 1 stöds utan att schema_version ändras. Läs `portion-scaling.md` för format, referenser, ordformer och validering. Varje känd mängd i ett konverterat recept har en källa och delas av lista och steg. Installera appstödet före referensrecept. Konvertera inte andra recept utan användarens begäran.

## Visuella timers i receptstandard v10

Alla nya eller uppdaterade receptpaket ska innehålla `timers.json`, även om `timers` är en tom lista. Varje uttrycklig stegtid ska ha en granskad timer på rätt steg. Intervall använder nedre gränsen med hela intervallet i notisen. Separata faser och båda sidor får egna timers. Vaga tider och förpackningsanvisningar får ingen påhittad tid. Tider portionsskalas aldrig. App 1.6.0 är bakåtkompatibel med äldre recept utan fil. Se timerstandarden och kör receptvalidatorn före publicering. Receptets schema_version är fortsatt 1.

## Filgräns vid publicering

Skillpaket v12 kräver en platt receptmapp med enbart tillåtna datafiler och refererade bilder. Se `recipe-files.md`; ingen ändring av schema_version eller befintliga recept krävs.
